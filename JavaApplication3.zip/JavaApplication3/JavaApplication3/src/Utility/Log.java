/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utility;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class Log {
    private static Log instance;
    private PrintWriter writer;

    private Log() {
        try {
            // Open the log file for appending
            writer = new PrintWriter(new FileWriter("src/log.txt", true));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Log getInstance() {
        if (instance == null) {
            synchronized (Log.class) {
                if (instance == null) {
                    instance = new Log();
                }
            }
        }
        return instance;
    }

    public void log(String message) {
        writer.println(new Date() + ": " + message);
        writer.flush();
    }

    public void close() {
        writer.close();
    }
}


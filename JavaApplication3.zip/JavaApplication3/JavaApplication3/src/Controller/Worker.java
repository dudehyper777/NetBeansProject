/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.ParcelMap;
import Model.Parcel;


public class Worker {
    private ParcelMap parcelMap;

    public Worker(ParcelMap parcelMap) {
        this.parcelMap = parcelMap;
    }
    public Worker()
    {
        
    }

   public double calculateFee(Parcel parcel) {
    double baseFee = 10.0;
    double weightFee = parcel.getWeight() * 0.5;
    double storageFee = parcel.getDaysInDepot() * 0.75;
    double fee = baseFee + weightFee + storageFee;

    // Log or display details (optional)
    String detail = "Total Fee: $" + String.format("%.2f", fee) + "\n";
    System.out.println(detail); // This will log the details in the console

    return fee; // Return the calculated fee
}


    public Parcel processCollection(String parcelId) {
        Parcel parcel = parcelMap.findParcel(parcelId);
        if (parcel != null) {
            parcelMap.removeParcel(parcelId);
        }
        return parcel;
    }
}


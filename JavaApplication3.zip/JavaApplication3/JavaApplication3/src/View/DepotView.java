
package View;

import Controller.Worker;
import Model.Customer;
import Model.Parcel;
import Model.ParcelMap;
import Model.QueueOfCustomers;
import Utility.Log;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DepotView extends JFrame {
    private CardLayout cardLayout;
    private JPanel cardPanel;
    private JButton generateButton, SearchparcelButton, SearchcustomerButton, calculateFeesButton;
    private ParcelMap parcelMap;
    private QueueOfCustomers queueOfCustomers;
    private DefaultTableModel parcelTableModel, customerTableModel, processedTableModel;
    private JTable parcelTable, customerTable, processedTable;
    
    
    

    public DepotView() {
        initializeComponents();
        parcelMap = new ParcelMap();
        queueOfCustomers = new QueueOfCustomers();
    }

    private void initializeComponents() {
        setTitle("Depot System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        //workerButton = new JButton("Worker");
        generateButton = new JButton("Generate Report");
        SearchparcelButton = new JButton("Search Parcel");
        SearchcustomerButton = new JButton("Search Customer");
        calculateFeesButton = new JButton("Calculate Fees");
        
        generateButton.setBackground(Color.LIGHT_GRAY); // Set background color
        generateButton.setForeground(Color.BLACK); // Set text color

        calculateFeesButton.setBackground(Color.LIGHT_GRAY);
        calculateFeesButton.setForeground(Color.BLACK);

        SearchparcelButton.setBackground(Color.YELLOW);
        SearchparcelButton.setForeground(Color.BLACK);

        SearchcustomerButton.setBackground(Color.YELLOW);
        SearchcustomerButton.setForeground(Color.BLACK);


        JPanel buttonPanel = new JPanel();
        JPanel leftButtons = new JPanel();
        //buttonPanel.add(workerButton);
        leftButtons.add(generateButton);
        buttonPanel.add(SearchparcelButton);
        buttonPanel.add(SearchcustomerButton);
        leftButtons.add(calculateFeesButton); // Add the Calculate Fees button
        add(buttonPanel, BorderLayout.NORTH);
        add(leftButtons,BorderLayout.SOUTH);
        
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.add(createWorkerPanel(), "Worker");
        cardPanel.add(createAdminPanel(), "Admin");
        cardPanel.add(createCustomerPanel(), "Customer");
        cardPanel.add(createCustomerPanel1(), "Customer1");
        cardPanel.add(createCustomerPanel2(), "Fees");

        add(cardPanel, BorderLayout.CENTER);

        setupListeners();
    }

    
private JPanel createWorkerPanel() {
    JPanel panel = new JPanel(new BorderLayout());
    
    // Create the left panel which will contain the parcel and processed tables
    JPanel leftPanel = new JPanel();
    leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));  // Stack the tables vertically
    
    // Create the parcel table and add it to the left panel
    parcelTableModel = new DefaultTableModel(new Object[]{"ID", "Days in Depot", "Weight", "Length", "Width", "Height", "Status"}, 0);
    parcelTable = new JTable(parcelTableModel);
    JScrollPane parcelScrollPane = new JScrollPane(parcelTable);
    
    // Create the processed table and add it below the parcel table
    processedTableModel = new DefaultTableModel(new Object[]{"ID", "Days in Depot", "Weight", "Length", "Width", "Height", "Status"}, 0);
    processedTable = new JTable(processedTableModel);
    JScrollPane processedScrollPane = new JScrollPane(processedTable);

    // Add parcel and processed tables to the left panel
    leftPanel.add(parcelScrollPane);
    leftPanel.add(processedScrollPane);

    // Create the customer table and add it to the right side panel
    customerTableModel = new DefaultTableModel(new Object[]{"Queue No", "Name", "ID"}, 0);
    customerTable = new JTable(customerTableModel);
    JScrollPane customerScrollPane = new JScrollPane(customerTable);
    
    JPanel rightPanel = new JPanel(new BorderLayout());
    rightPanel.add(customerScrollPane, BorderLayout.CENTER);

    // Add both the left and right panels to the main panel
    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
    splitPane.setDividerLocation(600);  // Adjust the divider position as needed
    
    panel.add(splitPane, BorderLayout.CENTER);

    // Create button panel and add action listeners
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(createButton("Load Parcels", "src/Parcels.csv", parcelTableModel));
    buttonPanel.add(createButton("Load Customers", "src/Custs.csv", customerTableModel));
    
    // New functionality buttons
    JButton addCustomerBtn = new JButton("Add Customer");
    JButton removeCustomerBtn = new JButton("Remove Customer");
    JButton addParcelBtn = new JButton("Add Parcel");
    //JButton markParcelBtn = new JButton("Mark Parcel");

    addCustomerBtn.addActionListener(e -> addCustomer());
    removeCustomerBtn.addActionListener(e -> removeCustomer());
    addParcelBtn.addActionListener(e -> addParcel());
    //markParcelBtn.addActionListener(e -> markParcel());

    buttonPanel.add(addCustomerBtn);
    buttonPanel.add(removeCustomerBtn);
    buttonPanel.add(addParcelBtn);
    //buttonPanel.add(markParcelBtn);

    // Add buttons to the bottom of the panel
    panel.add(buttonPanel, BorderLayout.SOUTH);

    return panel;
}



    private JButton createButton(String title, String filePath, DefaultTableModel model) {
        JButton button = new JButton(title);
        button.addActionListener(e -> loadData(filePath, model));
        return button;
    }


private void loadData(String filePath, DefaultTableModel model) {
    // Clear the existing data from the table model before loading new data
    model.setRowCount(0);

    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
        ArrayList<Customer> tempCustomers = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            if (model == parcelTableModel) {
                // Append "Unprocessed" status to parcel data array
                String[] fullData = new String[data.length + 1]; // create a new array with an extra slot for the status
                System.arraycopy(data, 0, fullData, 0, data.length);
                fullData[data.length] = "Unprocessed"; // set the default status

                Parcel parcel = new Parcel(data[0], Integer.parseInt(data[1]), Double.parseDouble(data[2]),
                        Integer.parseInt(data[3]), Integer.parseInt(data[4]), Integer.parseInt(data[5]));
                parcelMap.addParcel(parcel);
                model.addRow(fullData);
            } else if (model == customerTableModel) {
                if (parcelMap.containsParcel(data[1])) {
                    Parcel parcel = parcelMap.findParcel(data[1]);
                    tempCustomers.add(new Customer(0, data[0], data[1]));
                    // After loading the customer, mark the associated parcel as "Processed"
                    if (parcel != null) {
                        parcel.markAsProcessed();  // Mark the parcel as processed

                        // Update the parcel status in the parcel table as well
                        for (int i = 0; i < parcelTableModel.getRowCount(); i++) {
                            if (parcelTableModel.getValueAt(i, 0).equals(data[1])) { // Match by Parcel ID
                                parcelTableModel.setValueAt("Processed", i, 6); // Update the "Status" column
                                break;
                            }
                        }
                        
                        processedTableModel.addRow(new Object[]{parcel.getId(), parcel.getDaysInDepot(), parcel.getWeight(),
                        parcel.getLength(), parcel.getWidth(), parcel.getHeight(), "Processed"});   
                    }
                }
            }
        }
        if (model == customerTableModel) {
            // Sort the customers by the number of days the associated parcel has been in the depot
            Collections.sort(tempCustomers, (c1, c2) -> {
                Parcel p1 = parcelMap.findParcel(c1.getParcelId());
                Parcel p2 = parcelMap.findParcel(c2.getParcelId());
                return Integer.compare(p2 != null ? p2.getDaysInDepot() : -1, p1 != null ? p1.getDaysInDepot() : -1);
            });
            int queueNumber = 1;
            for (Customer customer : tempCustomers) {
                model.addRow(new Object[]{queueNumber, customer.getName(), customer.getParcelId()});
                customer.setQueueNumber(queueNumber++);
                queueOfCustomers.enqueue(customer);
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


private JPanel createAdminPanel() {
    JPanel panel = new JPanel(new BorderLayout());
    
    // Generate report button
    JButton generateReportButton = new JButton("Generate Report");
    generateReportButton.addActionListener(this::generateReport);
    
    // Back button
    JButton backButton = new JButton("Back");
    backButton.addActionListener(e -> cardLayout.show(cardPanel, "Worker")); // Switch to the Worker panel
    
    // Add buttons to the panel
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(generateReportButton);
    buttonPanel.add(backButton);
    
    panel.add(buttonPanel, BorderLayout.NORTH);
    return panel;
}

    
    private void generateReport(ActionEvent event) {
    File file = new File("src/report.csv");
    try (PrintWriter writer = new PrintWriter(file)) {
        // Write headers
        for (int col = 0; col < parcelTableModel.getColumnCount(); col++) {
            writer.print(parcelTableModel.getColumnName(col));
            if (col < parcelTableModel.getColumnCount() - 1) {
                writer.print(",");
            }
        }
        writer.println();

        // Write rows
        for (int row = 0; row < parcelTableModel.getRowCount(); row++) {
            for (int col = 0; col < parcelTableModel.getColumnCount(); col++) {
                writer.print(parcelTableModel.getValueAt(row, col));
                if (col < parcelTableModel.getColumnCount() - 1) {
                    writer.print(",");
                }
            }
            writer.println();
        }
        JOptionPane.showMessageDialog(this, "Report generated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (FileNotFoundException e) {
        JOptionPane.showMessageDialog(this, "Error saving log: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    
    private JPanel createCustomerPanel() {
    JPanel panel = new JPanel(new BorderLayout()); // Use BorderLayout for better positioning

    // Top panel for search field, buttons, and back button
    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Align components to the left
    JLabel searchLabel = new JLabel("Enter Parcel ID:");
    JTextField searchField = new JTextField(20);
    JButton searchButton = new JButton("Search");
    JButton backButton = new JButton("Back");

    // Add action listener for Search button
    searchButton.addActionListener(e -> searchParcel(searchField.getText(), panel));

    // Add action listener for Back button
    backButton.addActionListener(e -> cardLayout.show(cardPanel, "Worker")); // Switch to Worker panel

    // Add components to the top panel
    topPanel.add(searchLabel);
    topPanel.add(searchField);
    topPanel.add(searchButton);
    topPanel.add(backButton);

    // Add the top panel to the main panel
    panel.add(topPanel, BorderLayout.NORTH);

    return panel;
}

    
    private JPanel createCustomerPanel1() {
    JPanel panel = new JPanel(new BorderLayout()); // Use BorderLayout for the main panel
    
    // Create a panel for the search field, search button, and back button
    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Align components to the left
    JTextField searchField = new JTextField(20);
    JButton searchButton = new JButton("Search");
    JButton backButton = new JButton("Back");
    
    // Add action listeners
    searchButton.addActionListener(e -> searchCustomer(searchField.getText(), panel));
    backButton.addActionListener(e -> cardLayout.show(cardPanel, "Worker")); // Switch to the Worker panel
    
    // Add components to the top panel
    topPanel.add(searchField);
    topPanel.add(searchButton);
    topPanel.add(backButton);
    
    // Add the top panel to the main panel
    panel.add(topPanel, BorderLayout.NORTH);
    
    return panel;
}

    
    Parcel parcel;
        
    Worker worker= new Worker();
private JPanel createCustomerPanel2() {
    JPanel panel = new JPanel(new BorderLayout()); // Use BorderLayout for the main panel

    // Create a panel for the top components
    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Align components to the left

    // Create components
    JLabel label = new JLabel("Enter Parcel ID:");
    JTextField searchField = new JTextField(20); // Field to enter Parcel ID
    JButton calculateButton = new JButton("Calculate Fees");
    JButton backButton = new JButton("Back");

    // Add action listener to the Calculate button
    calculateButton.addActionListener(e -> {
        String parcelId = searchField.getText(); // Get entered Parcel ID

        // Check if Parcel ID is entered
        if (parcelId.isEmpty()) {
            JOptionPane.showMessageDialog(panel, "Please enter a Parcel ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Search for the parcel in the parcel table model
        Parcel parcel = findParcelById(parcelId);

        if (parcel != null) {
            // Calculate the fees
            double totalFees = worker.calculateFee(parcel);

            // Display the calculated fees
            String details = "Parcel ID: " + parcelId + "\n" +
                             "Total Fees: $" + String.format("%.2f", totalFees);

            JOptionPane.showMessageDialog(panel, details, "Fee Calculation", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Show error if the parcel is not found
            JOptionPane.showMessageDialog(panel, "Parcel not found with ID: " + parcelId, "Search Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    // Add action listener to the Back button
    backButton.addActionListener(e -> cardLayout.show(cardPanel, "Worker")); // Switch to the Worker panel

    // Add components to the top panel
    topPanel.add(label);
    topPanel.add(searchField);
    topPanel.add(calculateButton);
    topPanel.add(backButton);

    // Add the top panel to the main panel
    panel.add(topPanel, BorderLayout.NORTH);

    return panel;
}


// Helper method to find a Parcel by ID from the parcel table model
private Parcel findParcelById(String parcelId) {
    for (int row = 0; row < parcelTableModel.getRowCount(); row++) {
        if (parcelTableModel.getValueAt(row, 0).equals(parcelId)) {
            // Assuming Parcel has a constructor to initialize with table row data
            double weight = Double.parseDouble(String.valueOf(parcelTableModel.getValueAt(row, 2)));
            int daysInDepot = Integer.parseInt(String.valueOf(parcelTableModel.getValueAt(row, 1)));
            int length = Integer.parseInt(String.valueOf(parcelTableModel.getValueAt(row, 3)));
            int width = Integer.parseInt(String.valueOf(parcelTableModel.getValueAt(row, 4)));
            int height = Integer.parseInt(String.valueOf(parcelTableModel.getValueAt(row, 5)));

            // Create and return the Parcel object
            return new Parcel(parcelId, daysInDepot, weight,length, width, height);
        }
    }
    return null; // Return null if not found
}





    private void searchParcel(String id, JPanel panel) {
    for (int row = 0; row < parcelTableModel.getRowCount(); row++) {
        if (parcelTableModel.getValueAt(row, 0).equals(id)) {
            // Assuming the table columns are ID, Days in Depot, Weight, Length, Width, Height in order
            String parcelId = String.valueOf(parcelTableModel.getValueAt(row, 0));
            String daysInDepot = String.valueOf(parcelTableModel.getValueAt(row, 1));
            String weight = String.valueOf(parcelTableModel.getValueAt(row, 2));
            String dimensions = String.valueOf(parcelTableModel.getValueAt(row, 3)) + " x " +
                                String.valueOf(parcelTableModel.getValueAt(row, 4)) + " x " +
                                String.valueOf(parcelTableModel.getValueAt(row, 5));

            String details = "Parcel ID: " + parcelId + "\n" +
                             "Days in Depot: " + daysInDepot + "\n" +
                             "Weight: " + weight + " kg\n" +
                             "Dimensions: " + dimensions + " (L x W x H)";

            JOptionPane.showMessageDialog(panel, details, "Parcel Details", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
    }
    JOptionPane.showMessageDialog(panel, "Parcel not found", "Search", JOptionPane.INFORMATION_MESSAGE);
}
    
    private void searchCustomer(String lastName, JPanel panel) {
    for (int row = 0; row < customerTableModel.getRowCount(); row++) {
        String fullName = String.valueOf(customerTableModel.getValueAt(row, 1)); // Assuming full name is in the second column
        String customerId = String.valueOf(customerTableModel.getValueAt(row, 2)); // Assuming customer ID is in the third column

        // Split the full name to extract the last name (assuming the last name is the last word in the full name)
        String[] nameParts = fullName.split(" ");
        String customerLastName = nameParts[nameParts.length - 1];  // Last name is the last word

        // Check if the last name matches the entered last name (case insensitive)
        if (customerLastName.equalsIgnoreCase(lastName)) {
            // Now find the associated parcel ID for this customer
            String parcelId = getParcelIdForCustomer(customerId);

            String details = "Customer Name: " + fullName + "\n" +
                             "Parcel ID: " + parcelId;

            JOptionPane.showMessageDialog(panel, details, "Customer Details", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
    }
    JOptionPane.showMessageDialog(panel, "Customer with last name '" + lastName + "' not found", "Search", JOptionPane.INFORMATION_MESSAGE);

}

private String getParcelIdForCustomer(String customerId) {
    
    for (int row = 0; row < parcelTableModel.getRowCount(); row++) {
        String associatedCustomerId = String.valueOf(parcelTableModel.getValueAt(row, 0)); // Assuming parcel ID is the first column
        if (associatedCustomerId.equals(customerId)) {
            return String.valueOf(parcelTableModel.getValueAt(row, 0));  // Returning the Parcel ID associated with this customer
        }
    }
    return "No Parcel Found";  // If no parcel is found for the customer
}

    
    
    private void setupListeners() {
        //workerButton.addActionListener(e -> cardLayout.show(cardPanel, "Worker"));
        generateButton.addActionListener(e -> cardLayout.show(cardPanel, "Admin"));
        
        SearchparcelButton.addActionListener(e -> cardLayout.show(cardPanel, "Customer"));
        SearchcustomerButton.addActionListener(e -> cardLayout.show(cardPanel, "Customer1"));
        calculateFeesButton.addActionListener(e -> cardLayout.show(cardPanel, "Fees")); // Trigger the fees calculation when clicked
        
    }


private void addCustomer() {
    JTextField nameField = new JTextField(10);
    JTextField parcelIdField = new JTextField(10);
    JPanel panel = new JPanel(new GridLayout(0, 1));
    panel.add(new JLabel("Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Parcel ID:"));
    panel.add(parcelIdField);

    int result = JOptionPane.showConfirmDialog(null, panel, "Add New Customer",
        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if (result == JOptionPane.OK_OPTION) {
        String name = nameField.getText();
        String parcelId = parcelIdField.getText();
        if (!name.isEmpty() && !parcelId.isEmpty() && parcelMap.containsParcel(parcelId)) {
            int queueNumber = customerTableModel.getRowCount() + 1;
            Customer customer = new Customer(queueNumber, name, parcelId);
            customerTableModel.addRow(new Object[]{queueNumber, name, parcelId});
            queueOfCustomers.enqueue(customer);

            // Mark the parcel as processed after adding the customer
            Parcel parcel = parcelMap.findParcel(parcelId);
            if (parcel != null) {
                parcel.markAsProcessed(); // Mark the parcel as processed
                // Update the parcel status in the table as well
                for (int i = 0; i < parcelTableModel.getRowCount(); i++) {
                    if (parcelTableModel.getValueAt(i, 0).equals(parcelId)) {
                        parcelTableModel.setValueAt("Processed", i, 6); // Assuming "Status" is in column 6
                        break;
                    }
                }
                processedTableModel.addRow(new Object[]{parcel.getId(), parcel.getDaysInDepot(), parcel.getWeight(),
                        parcel.getLength(), parcel.getWidth(), parcel.getHeight(), "Processed"});
            }

            Log.getInstance().log("Added customer to queue: " + name);
            writeCustomerToFile(name, parcelId);  // Write customer to file
        } else {
            JOptionPane.showMessageDialog(null, "Invalid input or parcel does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}


private void writeCustomerToFile(String name, String parcelId) {
    try (FileWriter fw = new FileWriter("src/Custs.csv", true);
         BufferedWriter bw = new BufferedWriter(fw);
         PrintWriter out = new PrintWriter(bw)) {
        out.println(name + "," + parcelId);
    } catch (IOException e) {
        Log.getInstance().log("Failed to write customer to file: " + e.getMessage());
    }
}



private void removeCustomer() {
    int selectedRow = customerTable.getSelectedRow();
    if (selectedRow >= 0) {
        String customerId = customerTableModel.getValueAt(selectedRow, 2).toString(); // Assuming ID is at column index 2
        String parcelId = customerTableModel.getValueAt(selectedRow, 2).toString(); // Parcel ID is the same as customer ID
        
        // Find the associated parcel and mark it as "Unprocessed"
        Parcel parcel = parcelMap.findParcel(parcelId);
        if (parcel != null) {
            parcel.setStatus("Unprocessed"); // Update the parcel status to Unprocessed
            
            // Update the parcel status in the parcel table
            for (int i = 0; i < parcelTableModel.getRowCount(); i++) {
                if (parcelTableModel.getValueAt(i, 0).equals(parcelId)) { // Match by Parcel ID
                    parcelTableModel.setValueAt("Unprocessed", i, 6); // Update the "Status" column
                    break;
                }
            }
        }

        // Now remove the customer from the table and file
        customerTableModel.removeRow(selectedRow);
        if (removeCustomerFromFile(customerId)) {
            queueOfCustomers.remove(customerId); // Only remove from the queue if successfully removed from the file
            Log.getInstance().log("Removed customer: " + customerId);
        } else {
            JOptionPane.showMessageDialog(null, "Failed to remove customer from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No customer selected.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}


private boolean removeCustomerFromFile(String customerId) {
    File inputFile = new File("src/Custs.csv");
    File tempFile = new File("src/Custs_temp.csv");

    try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
         BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

        String currentLine;
        boolean found = false;

        while ((currentLine = reader.readLine()) != null) {
            String[] data = currentLine.split(",");
            if (data.length > 1 && data[1].equals(customerId)) {
                found = true;  
                continue;
            }
            writer.write(currentLine + System.lineSeparator());
        }

        if (!found) {
            JOptionPane.showMessageDialog(null, "Customer ID not found in file.", "Removal Failed", JOptionPane.ERROR_MESSAGE);
            return false;
        }

    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Failed to read or write during customer removal: " + e.getMessage(), "IO Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    // Perform file operations outside the try-with-resources block to ensure all streams are closed
    return replaceFile(inputFile, tempFile);
}

private boolean replaceFile(File inputFile, File tempFile) {
    if (!inputFile.delete()) {
        JOptionPane.showMessageDialog(null, "Failed to delete original file.", "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    if (!tempFile.renameTo(inputFile)) {
        JOptionPane.showMessageDialog(null, "Failed to rename temporary file.", "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    return true;
}


private void addParcel() {
    JTextField idField = new JTextField(10);
    JTextField daysField = new JTextField(10);
    JTextField weightField = new JTextField(10);
    JTextField lengthField = new JTextField(10);
    JTextField widthField = new JTextField(10);
    JTextField heightField = new JTextField(10);

    JPanel panel = new JPanel(new GridLayout(0, 2));
    panel.add(new JLabel("ID:"));
    panel.add(idField);
    panel.add(new JLabel("Days in Depot:"));
    panel.add(daysField);
    panel.add(new JLabel("Weight:"));
    panel.add(weightField);
    panel.add(new JLabel("Length:"));
    panel.add(lengthField);
    panel.add(new JLabel("Width:"));
    panel.add(widthField);
    panel.add(new JLabel("Height:"));
    panel.add(heightField);

    int result = JOptionPane.showConfirmDialog(null, panel, "Add New Parcel",
        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if (result == JOptionPane.OK_OPTION) {
        try {
            String id = idField.getText();
            int days = Integer.parseInt(daysField.getText());
            double weight = Double.parseDouble(weightField.getText());
            int length = Integer.parseInt(lengthField.getText());
            int width = Integer.parseInt(widthField.getText());
            int height = Integer.parseInt(heightField.getText());
            Parcel parcel = new Parcel(id, days, weight, length, width, height);
            parcelMap.addParcel(parcel);
            parcelTableModel.addRow(new Object[]{id, days, weight, length, width, height});
            Log.getInstance().log("Parcel added with ID: " + id);
            writeParcelToFile(id, days, weight, length, width, height);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input for number fields.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

private void writeParcelToFile(String id, int days, double weight, int length, int width, int height) {
    try (FileWriter fw = new FileWriter("src/Parcels.csv", true);
         BufferedWriter bw = new BufferedWriter(fw);
         PrintWriter out = new PrintWriter(bw)) {
        out.println(id + "," + days + "," + weight + "," + length + "," + width + "," + height);
    } catch (IOException e) {
        Log.getInstance().log("Failed to write parcel to file: " + e.getMessage());
        JOptionPane.showMessageDialog(null, "Failed to write parcel to file.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}


private void markParcel() {
    int selectedRow = parcelTable.getSelectedRow();
    if (selectedRow >= 0) {
        String id = parcelTableModel.getValueAt(selectedRow, 0).toString();
        Parcel parcel = parcelMap.findParcel(id);
        if (parcel != null) {
            parcel.markAsProcessed(); // Mark the parcel as processed
            parcelTableModel.setValueAt("Processed", selectedRow, 6); 
            Log.getInstance().log("Parcel with ID: " + id+ "Marked as Processed");

            
        } else {
            JOptionPane.showMessageDialog(null, "Parcel not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No parcel selected.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    
    
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new DepotView().setVisible(true));
    }
}
